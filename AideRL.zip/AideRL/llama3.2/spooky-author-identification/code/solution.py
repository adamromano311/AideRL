import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load the training and test data
train_df = pd.read_csv("./input/train.csv")
test_df = pd.read_csv("./input/test.csv")

# Split the data into training and validation sets
train_text, val_text, train_labels, val_labels = train_test_split(
    train_df["text"], train_df["author"], test_size=0.2, random_state=42
)

# Create a TF-IDF vectorizer
vectorizer = TfidfVectorizer(max_features=5000)

# Fit the vectorizer to the training data and transform both the training and validation data
X_train = vectorizer.fit_transform(train_text)
y_train = train_labels
X_val = vectorizer.transform(val_text)
y_val = val_labels

# Train a Naive Bayes classifier on the training data
clf = MultinomialNB()
clf.fit(X_train, y_train)

# Evaluate the model on the validation set
y_pred_val = clf.predict(X_val)
print("Validation Accuracy:", accuracy_score(y_val, y_pred_val))
print("Validation Classification Report:\n", classification_report(y_val, y_pred_val))
print("Validation Confusion Matrix:\n", confusion_matrix(y_val, y_pred_val))

# Make predictions on the test set
X_test = vectorizer.transform(test_df["text"])
y_pred_test = clf.predict(X_test)

# Save the predictions to a submission file
submission_df = pd.DataFrame(
    {
        "id": test_df["id"],
        "EAP": clf.predict_proba(X_test)[:, 0],
        "HPL": clf.predict_proba(X_test)[:, 1],
        "MWS": clf.predict_proba(X_test)[:, 2],
    }
)
submission_df.to_csv("./submission/submission.csv", index=False)
