import json
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import KFold
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.base import clone

# Load the data
with open("./input/train.json") as f:
    train_data = json.load(f)

with open("./input/test.json") as f:
    test_data = json.load(f)

train_df = pd.DataFrame(train_data)
test_df = pd.DataFrame(test_data)

# Extract features and target
common_features = [
    "request_text_edit_aware",
    "request_title",
    "requester_account_age_in_days_at_request",
    "requester_days_since_first_post_on_raop_at_request",
    "requester_number_of_comments_at_request",
    "requester_number_of_comments_in_raop_at_request",
    "requester_number_of_posts_at_request",
    "requester_number_of_posts_on_raop_at_request",
    "requester_number_of_subreddits_at_request",
    "requester_upvotes_minus_downvotes_at_request",
    "requester_upvotes_plus_downvotes_at_request",
]

X = train_df[common_features]
y = train_df["requester_received_pizza"]

X_test = test_df[common_features]

# Define the feature transformers
text_transformer = TfidfVectorizer(max_features=300, stop_words="english")
title_transformer = TfidfVectorizer(max_features=300, stop_words="english")

# Preprocessing for numerical features
numerical_features = X.select_dtypes(include=[np.number]).columns.tolist()
numerical_transformer = Pipeline(
    steps=[("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]
)

# Combine all features
preprocessor = ColumnTransformer(
    transformers=[
        ("num", numerical_transformer, numerical_features),
        ("text", text_transformer, "request_text_edit_aware"),
        ("title", title_transformer, "request_title"),
    ]
)

# Base models
catboost = CatBoostClassifier(verbose=0, random_seed=42)
logreg = LogisticRegression(max_iter=1000, random_state=42)
random_forest = RandomForestClassifier(n_estimators=100, random_state=42)

# Meta-model
meta_model = LogisticRegression(max_iter=1000, random_state=42)

# Evaluate the stacking ensemble using cross-validation
kf = KFold(n_splits=5, shuffle=True, random_state=42)
stacking_auc_scores = []

for train_index, val_index in kf.split(X):
    X_train, X_val = X.iloc[train_index], X.iloc[val_index]
    y_train, y_val = y.iloc[train_index], y.iloc[val_index]

    # Fit base models
    catboost_pipeline = Pipeline(
        steps=[("preprocessor", preprocessor), ("classifier", clone(catboost))]
    )
    logreg_pipeline = Pipeline(
        steps=[("preprocessor", preprocessor), ("classifier", clone(logreg))]
    )
    rf_pipeline = Pipeline(
        steps=[("preprocessor", preprocessor), ("classifier", clone(random_forest))]
    )

    catboost_pipeline.fit(X_train, y_train)
    logreg_pipeline.fit(X_train, y_train)
    rf_pipeline.fit(X_train, y_train)

    # Predict probabilities
    catboost_probs = catboost_pipeline.predict_proba(X_val)[:, 1]
    logreg_probs = logreg_pipeline.predict_proba(X_val)[:, 1]
    rf_probs = rf_pipeline.predict_proba(X_val)[:, 1]

    # Stack predictions as features for meta-model
    stacked_features = np.column_stack((catboost_probs, logreg_probs, rf_probs))
    meta_model.fit(stacked_features, y_val)

    # Predict with meta-model
    ensemble_probs = meta_model.predict_proba(stacked_features)[:, 1]

    # Calculate AUC
    auc_score = roc_auc_score(y_val, ensemble_probs)
    stacking_auc_scores.append(auc_score)

print(f"Mean Stacking Ensemble AUC: {np.mean(stacking_auc_scores)}")

# Fit the ensemble model on the entire dataset and predict on the test set
catboost_pipeline.fit(X, y)
logreg_pipeline.fit(X, y)
rf_pipeline.fit(X, y)

catboost_test_probs = catboost_pipeline.predict_proba(X_test)[:, 1]
logreg_test_probs = logreg_pipeline.predict_proba(X_test)[:, 1]
rf_test_probs = rf_pipeline.predict_proba(X_test)[:, 1]

# Stack test predictions for meta-model
stacked_test_features = np.column_stack(
    (catboost_test_probs, logreg_test_probs, rf_test_probs)
)
ensemble_test_probs = meta_model.predict_proba(stacked_test_features)[:, 1]

# Prepare submission
submission = pd.DataFrame(
    {
        "request_id": test_df["request_id"],
        "requester_received_pizza": ensemble_test_probs,
    }
)

# Save submission
submission.to_csv("./submission/submission.csv", index=False)
