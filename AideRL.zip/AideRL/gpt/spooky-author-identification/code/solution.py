import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder
import numpy as np

# Load data
train = pd.read_csv("./input/train.csv")
test = pd.read_csv("./input/test.csv")

# Prepare the data
X_train = train["text"]
y_train = train["author"]
X_test = test["text"]

# Encode the target labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)

# Vectorize the text data using TF-IDF
tfidf_vectorizer = TfidfVectorizer(max_features=10000)
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Train the logistic regression model
log_reg = LogisticRegression(max_iter=1000)

# Evaluate using cross-validation
cv_scores = cross_val_score(
    log_reg, X_train_tfidf, y_train_encoded, cv=5, scoring="neg_log_loss"
)
print(f"Cross-validated log loss: {-np.mean(cv_scores)}")

# Fit the model on the full training data
log_reg.fit(X_train_tfidf, y_train_encoded)

# Predict probabilities for the test set
test_probs = log_reg.predict_proba(X_test_tfidf)

# Prepare the submission file
submission = pd.DataFrame(test_probs, columns=label_encoder.classes_)
submission.insert(0, "id", test["id"])
submission.to_csv("./submission/submission.csv", index=False)
