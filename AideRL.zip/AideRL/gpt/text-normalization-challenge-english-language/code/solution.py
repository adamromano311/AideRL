import pandas as pd
from sklearn.model_selection import train_test_split
from collections import defaultdict
import csv

# Load the data
train = pd.read_csv("./input/en_train.csv")
test = pd.read_csv("./input/en_test_2.csv")

# Split the training data for validation
train_data, val_data = train_test_split(train, test_size=0.2, random_state=42)

# Create a mapping of 'before' to 'after' for each class
class_mappings = defaultdict(lambda: defaultdict(str))
for _, row in train_data.iterrows():
    class_mappings[row["class"]][row["before"]] = row["after"]

# Create a mapping of 'before' to 'class' for the training set
before_class_mapping = train_data.set_index("before")["class"].to_dict()


# Function to normalize tokens based on class mappings
def normalize_token(token, token_class):
    if token in class_mappings[token_class]:
        return class_mappings[token_class][token]
    else:
        return token  # Default to self if not found


# Predict on validation set
val_data["predicted"] = val_data.apply(
    lambda row: normalize_token(row["before"], row["class"]), axis=1
)

# Calculate accuracy on validation set
accuracy = (val_data["after"] == val_data["predicted"]).mean()
print(f"Validation Accuracy: {accuracy:.4f}")

# Prepare the test set for prediction
test["id"] = test["sentence_id"].astype(str) + "_" + test["token_id"].astype(str)
test["class"] = test["before"].map(lambda x: before_class_mapping.get(x, "PLAIN"))
test["after"] = test.apply(
    lambda row: normalize_token(row["before"], row["class"]), axis=1
)

# Save the submission file
submission = test[["id", "after"]]
submission.to_csv(
    "./submission/submission.csv", index=False, quoting=csv.QUOTE_NONNUMERIC
)
