import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.ensemble import GradientBoostingRegressor, StackingRegressor
from xgboost import XGBRegressor
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_log_error
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
import numpy as np

# Load the dataset
train_df = pd.read_csv("./input/train.csv")
test_df = pd.read_csv("./input/test.csv")

# Separate features and targets
X = train_df.drop(columns=["id", "formation_energy_ev_natom", "bandgap_energy_ev"])
y_formation = train_df["formation_energy_ev_natom"]
y_bandgap = train_df["bandgap_energy_ev"]

# Create polynomial features
poly = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly.fit_transform(X)

# Feature scaling
scaler = StandardScaler()
X_poly_scaled = scaler.fit_transform(X_poly)

# Train-test split for local validation
X_train, X_val, y_train_formation, y_val_formation = train_test_split(
    X_poly_scaled, y_formation, test_size=0.2, random_state=42
)
X_train, X_val, y_train_bandgap, y_val_bandgap = train_test_split(
    X_poly_scaled, y_bandgap, test_size=0.2, random_state=42
)

# Initialize base models
base_models = [
    ("gbr", GradientBoostingRegressor(random_state=42)),
    ("xgb", XGBRegressor(random_state=42)),
]

# Initialize meta-model
meta_model = RidgeCV()

# Initialize Stacking Regressor for formation energy
stacked_formation = StackingRegressor(
    estimators=base_models, final_estimator=meta_model, cv=5
)

# Initialize Stacking Regressor for bandgap energy
stacked_bandgap = StackingRegressor(
    estimators=base_models, final_estimator=meta_model, cv=5
)

# Train stacked models
stacked_formation.fit(X_train, y_train_formation)
stacked_bandgap.fit(X_train, y_train_bandgap)

# Predict on validation set
val_preds_formation = stacked_formation.predict(X_val)
val_preds_bandgap = stacked_bandgap.predict(X_val)

# Calculate RMSLE
rmsle_formation = np.sqrt(mean_squared_log_error(y_val_formation, val_preds_formation))
rmsle_bandgap = np.sqrt(mean_squared_log_error(y_val_bandgap, val_preds_bandgap))

# Print RMSLE for both targets
print(f"RMSLE for formation energy: {rmsle_formation}")
print(f"RMSLE for bandgap energy: {rmsle_bandgap}")

# Train on full dataset
stacked_formation.fit(X_poly_scaled, y_formation)
stacked_bandgap.fit(X_poly_scaled, y_bandgap)

# Prepare test set features
X_test = test_df.drop(columns=["id"])
X_test_poly = poly.transform(X_test)
X_test_poly_scaled = scaler.transform(X_test_poly)

# Predict on test set
test_preds_formation = stacked_formation.predict(X_test_poly_scaled)
test_preds_bandgap = stacked_bandgap.predict(X_test_poly_scaled)

# Create submission file
submission = pd.DataFrame(
    {
        "id": test_df["id"],
        "formation_energy_ev_natom": test_preds_formation,
        "bandgap_energy_ev": test_preds_bandgap,
    }
)
submission.to_csv("./submission/submission.csv", index=False)
