import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold
from scipy.stats import spearmanr
import numpy as np

# Load the data
train = pd.read_csv("./input/train.csv")
test = pd.read_csv("./input/test.csv")
sample_submission = pd.read_csv("./input/sample_submission.csv")

# Combine text features
train["text"] = (
    train["question_title"] + " " + train["question_body"] + " " + train["answer"]
)
test["text"] = (
    test["question_title"] + " " + test["question_body"] + " " + test["answer"]
)

# TF-IDF Vectorization with character-level n-grams
vectorizer = TfidfVectorizer(max_features=5000, analyzer="char_wb", ngram_range=(2, 6))
X_train = vectorizer.fit_transform(train["text"])
X_test = vectorizer.transform(test["text"])

# Target columns
target_cols = sample_submission.columns[1:]

# Prepare for cross-validation
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# Store predictions
test_preds = np.zeros((test.shape[0], len(target_cols)))
oof_preds = np.zeros((train.shape[0], len(target_cols)))

# Train a model for each target
for i, target in enumerate(target_cols):
    y = train[target].values
    oof_fold_preds = np.zeros(train.shape[0])

    for train_index, val_index in kf.split(X_train):
        X_tr, X_val = X_train[train_index], X_train[val_index]
        y_tr, y_val = y[train_index], y[val_index]

        model = Ridge(alpha=1.0)
        model.fit(X_tr, y_tr)

        oof_fold_preds[val_index] = model.predict(X_val)
        test_preds[:, i] += model.predict(X_test) / kf.n_splits

    oof_preds[:, i] = oof_fold_preds
    print(
        f"{target}: Spearman correlation = {spearmanr(y, oof_fold_preds).correlation}"
    )

# Calculate mean Spearman correlation
mean_spearman = np.mean(
    [
        spearmanr(train[target_cols[i]], oof_preds[:, i]).correlation
        for i in range(len(target_cols))
    ]
)
print(f"Mean Spearman correlation: {mean_spearman}")

# Prepare submission
submission = pd.DataFrame(test_preds, columns=target_cols)
submission.insert(0, "qa_id", test["qa_id"])
submission.to_csv("./submission/submission.csv", index=False)
