import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.metrics import accuracy_score
from sklearn.feature_extraction.text import TfidfVectorizer

# Load the data
train_df = pd.read_csv("./input/train.csv")
test_df = pd.read_csv("./input/test.csv")

# Split the data into training and validation sets
train_text, val_text, train_labels, val_labels = train_test_split(
    train_df["text"], train_df["author"], test_size=0.2, random_state=42
)

# Create a bag-of-words representation of the text data
vectorizer = CountVectorizer(stop_words="english")
X_train = vectorizer.fit_transform(train_text)
y_train = train_labels
X_val = vectorizer.transform(val_text)
y_val = val_labels

# Train an SVM classifier on the training data
clf = svm.SVC()
clf.fit(X_train, y_train)

# Make predictions on the validation data
y_pred = clf.predict(X_val)

# Evaluate the accuracy of the classifier
accuracy = accuracy_score(y_val, y_pred)
print("Accuracy:", accuracy)

# Make predictions on the test data
test_text = test_df["text"]
test_X = vectorizer.transform(test_text)
test_pred = clf.predict(test_X)

# Save the predictions to a submission.csv file
submission_df = pd.DataFrame(
    {
        "id": test_df["id"],
        "EAP": test_pred == "EAP",
        "HPL": test_pred == "HPL",
        "MWS": test_pred == "MWS",
    }
)
submission_df.to_csv("./submission/submission.csv", index=False)
