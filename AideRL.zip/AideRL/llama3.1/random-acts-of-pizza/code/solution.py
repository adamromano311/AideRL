import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score

# Load the data
train_df = pd.read_json("input/train/train.json")
test_df = pd.read_json("input/test/test.json")

# Extract the request text from the JSON data
train_text = train_df["request_text_edit_aware"]
test_text = test_df["request_text_edit_aware"]

# Create a TfidfVectorizer and fit it to the training data
vectorizer = TfidfVectorizer(stop_words="english")
vectorizer.fit(train_text)

# Transform the training and test data using the fitted vectorizer
train_text_vectorized = vectorizer.transform(train_text)
test_text_vectorized = vectorizer.transform(test_text)

# Split the data into training and validation sets
train_text_vectorized, val_text_vectorized, train_labels, val_labels = train_test_split(
    train_text_vectorized,
    train_df["requester_received_pizza"],
    test_size=0.2,
    random_state=42,
)

# Train a gradient boosting classifier
gbc = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, random_state=42)
gbc.fit(train_text_vectorized, train_labels)

# Make predictions on the validation set
val_pred = gbc.predict_proba(val_text_vectorized)[:, 1]

# Evaluate the model using AUC-ROC
auc = roc_auc_score(val_labels, val_pred)
print("AUC-ROC:", auc)

# Make predictions on the test set
test_pred = gbc.predict_proba(test_text_vectorized)[:, 1]

# Save the predictions to a submission file
submission_df = pd.DataFrame(
    {"request_id": test_df["request_id"], "requester_received_pizza": test_pred}
)
submission_df.to_csv("submission/submission.csv", index=False)
